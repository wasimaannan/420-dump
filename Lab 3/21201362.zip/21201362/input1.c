int x,y,z; float a;

int func(int c, int d){
	return 7;
}

int correct_foo(int a, float b){
	return a+3;
}


void foo(int a){
	y = 6;
}

int foo2(int a, int a, float b){
	return a + 2;
}

void foo3(int a , int b){
	y = 7;
}

int z(int d){
	return d;
}

int var(int a){
	return a;
}

void foo4(int a){
	return a+3;
}

int main(){
	int a,b,c[4],dd,ee;	
	void e;
	float a,c[7];
	
	func(2.5,3.5);
	
	
	a = correct_foo(a,c);
	b = correct_foo(a);
	
	k = 5+2;
	b[5] = 7;
	c[2.5] = 8;
	c[0] = 2 + 5 * foo4(7);
	c[1] = 5;
	foo4(c[1]);
	c[2] = foo4(c[1]);
	c[3] = 2.7;
	b = 5%0;
	b = 2%3.5;
	
	dd = foo5(a);
	
	printf(h);
	return 0;
	
	
}
